"""
EdgeCrafter: Compact ViTs for Edge Dense Prediction via Task-Specialized Distillation
Copyright (c) 2026 The EdgeCrafter Authors. All Rights Reserved.
---------------------------------------------------------------------------------
DEIMv2: Real-Time Object Detection Meets DINOv3
Copyright (c) 2025 The DEIMv2 Authors. All Rights Reserved.
---------------------------------------------------------------------------------
DEIM: DETR with Improved Matching for Fast Convergence
Copyright (c) 2024 The DEIM Authors. All Rights Reserved.
---------------------------------------------------------------------------------
Modified from RT-DETR (https://github.com/lyuwenyu/RT-DETR)
Copyright (c) 2023 lyuwenyu. All Rights Reserved.
"""
import os
import sys
import warnings


sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

import argparse

from engine.core import YAMLConfig, yaml_utils
from engine.misc import dist_utils
from engine.solver import TASKS

debug=False

warnings.filterwarnings("ignore")
warnings.filterwarnings("always", message=".*stop_epoch.*")

if debug:
    import torch
    torch.xpu.empty_cache()
    def custom_repr(self):
        return f'{{Tensor:{tuple(self.shape)}}} {original_repr(self)}'
    original_repr = torch.Tensor.__repr__
    torch.Tensor.__repr__ = custom_repr

def main(args, ) -> None:
    """main
    """
    # Seed bug fix: build the cfg FIRST (so `-u seed=` and yaml `seed` are merged in
    # precedence `--seed` > `-u seed=` > yaml `seed`), then seed the RNG with exactly
    # `cfg.seed`. Previously `setup_distributed(seed=args.seed)` ran first with the
    # --seed default of 0 and also clobbered `-u seed=` in update_dict.
    update_dict = yaml_utils.parse_cli(args.update) # update cfg from command line
    update_dict.update({k: v for k, v in args.__dict__.items() \
        if k not in ['update', ] and v is not None})

    assert not all([args.tuning, args.resume]), \
        'Only support from_scrach or resume or tuning at one time'

    cfg = YAMLConfig(args.config, **update_dict)

    if args.resume or args.tuning:
        if 'ViTAdapter' in cfg.yaml_cfg:
            cfg.yaml_cfg['ViTAdapter']['skip_load_backbone'] = True

    print('cfg: ', cfg.__dict__)

    # --dry: parse + print only (no dist init, no data, no XPU)
    if getattr(args, 'dry', False):
        td = cfg.yaml_cfg.get('train_dataloader', {}) or {}
        print(f'[dry] config parsed OK | seed={cfg.seed} epochs={cfg.epochs} '
              f'train_bs={td.get("total_batch_size")} early_stop={cfg.yaml_cfg.get("early_stop")}')
        return

    dist_utils.setup_distributed(args.print_rank, args.print_method, seed=cfg.seed)

    solver = TASKS[cfg.yaml_cfg['task']](cfg)

    if args.test_only:
        solver.val()
    else:
        solver.fit()

    # Optional peak-memory probe for throughput benchmarking (env-gated, harmless otherwise).
    if os.environ.get('LOG_XPU_MEM'):
        import torch
        acc = getattr(torch, 'xpu', None) or getattr(torch, 'cuda', None)
        try:
            print(f'[mem] peak_alloc_gb={acc.max_memory_allocated()/1e9:.2f}')
        except Exception as e:                                   # noqa: BLE001
            print(f'[mem] unavailable: {e}')

    dist_utils.cleanup()


if __name__ == '__main__':

    parser = argparse.ArgumentParser()

    # priority 0
    parser.add_argument('-c', '--config', type=str, default='')
    parser.add_argument('-r', '--resume', type=str, help='resume from checkpoint')
    parser.add_argument('-t', '--tuning', type=str, help='tuning from checkpoint')
    parser.add_argument('-d', '--device', type=str, help="device (e.g. 'cuda:0', 'xpu:0', 'xpu' or 'cpu')")
    parser.add_argument('--seed', type=int, default=None, help='exp reproducibility (overrides -u seed=)')
    parser.add_argument('--use-amp', action='store_true', default=None, help='auto mixed precision training')
    parser.add_argument('--output-dir', type=str, help='output directoy')
    parser.add_argument('--summary-dir', type=str, help='tensorboard summry')
    parser.add_argument('--test-only', action='store_true', default=False,)
    parser.add_argument('--dry', action='store_true', default=False,
                        help='parse config, print it, and exit (no data / no XPU)')

    # priority 1
    parser.add_argument('-u', '--update', nargs='+', help='update yaml config')

    # env
    parser.add_argument('--print-method', type=str, default='builtin', help='print method')
    parser.add_argument('--print-rank', type=int, default=0, help='print rank id')

    parser.add_argument('--local-rank', type=int, help='local rank id')
    args = parser.parse_args()

    main(args)
